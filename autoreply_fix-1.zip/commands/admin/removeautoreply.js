const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const locale = require('../../utils/locale');
const { success, error } = require('../../utils/embeds');
const db = require('../../database/db');
const logger = require('../../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('removeautoreply')
    .setDescription('حذف رد تلقائي')
    .addStringOption((o) => o.setName('trigger').setDescription('عبارة التشغيل للحذف').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction) {
    try {
      const trigger = String(interaction.options.getString('trigger') || '')
        .trim()
        .toLowerCase();

      if (!trigger) {
        return interaction.reply({
          embeds: [error('نص التشغيل فارغ أو غير صالح.')],
          flags: MessageFlags.Ephemeral
        });
      }

      const result = db.removeAutoReply(interaction.guildId, trigger);

      if (!result || !result.changes) {
        return interaction.reply({
          embeds: [error(locale.get('general.notFound'))],
          flags: MessageFlags.Ephemeral
        });
      }

      return interaction.reply({
        embeds: [success(locale.get('moderation.autoReplyRemoved', { trigger }))],
        flags: MessageFlags.Ephemeral
      });
    } catch (err) {
      logger.error('[Command Error - removeautoreply.js]:', err);
      try {
        const payload = {
          content: '❌ حدث خطأ أثناء تنفيذ هذا الأمر.',
          flags: MessageFlags.Ephemeral
        };
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp(payload).catch(() => null);
        } else {
          await interaction.reply(payload).catch(() => null);
        }
      } catch (_) {
        /* ignore */
      }
    }
  }
};

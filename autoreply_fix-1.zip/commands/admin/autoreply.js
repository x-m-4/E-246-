const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const locale = require('../../utils/locale');
const { success, error } = require('../../utils/embeds');
const db = require('../../database/db');
const logger = require('../../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('autoreply')
    .setDescription('إضافة رد تلقائي')
    .addStringOption((o) => o.setName('trigger').setDescription('نص التشغيل').setRequired(true))
    .addStringOption((o) => o.setName('response').setDescription('نص الرد').setRequired(true))
    .addBooleanOption((o) => o.setName('delete_message').setDescription('مسح رسالة العضو بعد الرد'))
    .addStringOption((o) =>
      o
        .setName('mode')
        .setDescription('طريقة الرد')
        .addChoices(
          { name: 'رد (Reply)', value: 'reply' },
          { name: 'رسالة منفصلة (Message)', value: 'message' }
        )
    )
    .addStringOption((o) =>
      o
        .setName('match')
        .setDescription('طريقة المطابقة')
        .addChoices(
          { name: 'تطابق تام (Exact)', value: 'exact' },
          { name: 'يحتوي على (Contains)', value: 'contains' }
        )
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction) {
    try {
      const triggerRaw = interaction.options.getString('trigger');
      const trigger = String(triggerRaw || '')
        .trim()
        .toLowerCase();
      const response = interaction.options.getString('response');
      const deleteTrigger = interaction.options.getBoolean('delete_message') ? 1 : 0;
      const mode = interaction.options.getString('mode') || 'reply';
      const matchType = interaction.options.getString('match') || 'exact';

      if (!trigger) {
        return interaction.reply({
          embeds: [error('نص التشغيل فارغ أو غير صالح.')],
          flags: MessageFlags.Ephemeral
        });
      }

      if (!response || !String(response).trim()) {
        return interaction.reply({
          embeds: [error('نص الرد فارغ أو غير صالح.')],
          flags: MessageFlags.Ephemeral
        });
      }

      const existing = db.getAutoReplies(interaction.guildId).find((r) => r.trigger === trigger);
      if (existing) {
        return interaction.reply({
          embeds: [error(locale.get('general.alreadyExists'))],
          flags: MessageFlags.Ephemeral
        });
      }

      db.addAutoReply(interaction.guildId, trigger, response, deleteTrigger, mode, matchType);

      const msg = locale.get('moderation.autoReplyAdded', { trigger, response });
      return interaction.reply({
        embeds: [success(msg)],
        flags: MessageFlags.Ephemeral
      });
    } catch (err) {
      logger.error('[Command Error - autoreply.js]:', err);
      try {
        const payload = {
          content: '❌ حدث خطأ أثناء تنفيذ هذا الأمر.',
          flags: MessageFlags.Ephemeral
        };
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp(payload).catch(() => null);
        } else {
          await interaction.reply(payload).catch(() => null);
        }
      } catch (_) {
        /* ignore */
      }
    }
  }
};
